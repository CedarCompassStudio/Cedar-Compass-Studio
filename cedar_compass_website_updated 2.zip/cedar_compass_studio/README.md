# Cedar & Compass Studio — launch instructions

This is a responsive, static website. It runs locally by opening `index.html` in a browser. No framework or paid hosting is needed.

## What works now
- Responsive navigation, shop, service listings, FAQ, and affiliate-resource section.
- Service inquiry buttons open an email draft **after** you set `contactEmail` in `config.js`.
- Product buttons open secure external checkout links **after** you add them to `checkoutLinks`.
- Until configured, product buttons clearly identify the store as a demo. No payment is collected.

## Free launch path
1. Choose a business email you control and enter it in `config.js` as `contactEmail`.
2. Create the actual digital product files (PDF templates, planners, etc.). The products listed are samples, not finished download files.
3. Open an account with a digital-product sales platform such as Payhip or Gumroad. Check its current transaction fees and supported payout methods. Upload each real product, set a price, and configure digital delivery.
4. Copy each product's **actual checkout URL** into the matching entry in `config.js`. Test purchases and delivery in the provider's supported test mode before launch.
5. Create a free GitHub account and a public repository. Upload `index.html` and `config.js`. In Settings → Pages, publish from the main branch root; use the free `github.io` URL. Alternatively use a static-hosting service's free tier, subject to current terms.
6. Verify mobile display, all buttons, email links, checkout links, download delivery, payment payouts, refund terms, and tax obligations before announcing launch.
7. Replace sample copy with accurate service descriptions, turnaround times, portfolio examples, and real business contact information. Add privacy policy and clear refund/service terms appropriate to your operations. Do not make unsubstantiated income or ancestry claims.
8. Apply to relevant affiliate programs only after you have suitable content and are eligible. Add approved links in `affiliateLinks` and make conspicuous affiliate disclosures wherever links appear. Never paste API secrets into this public file.

## $0 budget reality
Free hosting and free-to-start sales platforms may be possible. Payment processors and marketplaces typically deduct fees from sales. A custom domain, paid tools, business registration, or taxes may cost money later. Affiliate income requires approval and traffic. There is no guarantee of sales.

## Customization
Change visible branding, product descriptions, prices, and section text in `index.html`; configure links and email in `config.js`. Prices displayed on this page must match the checkout prices you set on your payment platform.

## Important
The site does not process cards or store customer information. Payments and file fulfillment are handled by the third-party platform you choose. Do not use direct email for sensitive genealogical records.

## Square checkout integration — October 2026
- Family History Starter Kit ($15) checkout URL is configured as `https://squareup.com/i/CEDARCOMP1` in `config.js`, as supplied by the owner. **Its validity, merchant ownership, amount, and live checkout status have not been independently verified.**
- The finished `Family_History_Starter_Kit.pdf` is included in this folder. **Do not publish this paid PDF in a public GitHub Pages repository**; it would be accessible for free. Upload only `index.html` and `config.js` to public hosting.
- Square Payment Links generally handle payment, **not automatic delivery of a PDF on this static website**. Before accepting payments, set `contactEmail` in `config.js`, confirm the Square link opens the correct $15 item, and set up a private delivery process. For a $0 start, manually email the PDF after verifying each payment in your Square dashboard. Avoid asking buyers to email card information.
- If using manual fulfillment, prominently state delivery time (e.g. within 1 business day) and refund policy on the site before launch. The site currently warns fulfillment is manual.
- For automatic delivery, use an approved digital-download fulfillment service or a custom secure backend/webhook (may have costs). Do not place the PDF in a publicly accessible site folder.
