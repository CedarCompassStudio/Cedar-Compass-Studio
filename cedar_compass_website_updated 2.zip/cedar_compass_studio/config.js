// Update this file before publishing. No secrets or API keys belong here.
window.SITE_CONFIG = {
  contactEmail: "",
  checkoutLinks: {
    "Monthly Budget Planner": "",
    "Family History Starter Kit": "https://squareup.com/i/CEDARCOMP1",
    "Weekly Focus Planner": ""
  },
  affiliateLinks: [
    // Example: { label: "Recommended planner", url: "https://your-approved-affiliate-link.example" }
  ]
};
